package com.shaadipros.shaadipros_data_collection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShaadiprosDataCollectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
