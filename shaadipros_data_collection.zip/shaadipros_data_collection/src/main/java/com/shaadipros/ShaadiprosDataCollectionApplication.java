package com.shaadipros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShaadiprosDataCollectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShaadiprosDataCollectionApplication.class, args);
	}

}
