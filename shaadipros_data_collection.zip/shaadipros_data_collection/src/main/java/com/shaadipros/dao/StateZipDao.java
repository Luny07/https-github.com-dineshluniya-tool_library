package com.shaadipros.dao;

import org.springframework.data.repository.CrudRepository;

import com.shaadipros.entity.StateZipCode;

public interface StateZipDao extends CrudRepository<StateZipCode, Integer>{

}
