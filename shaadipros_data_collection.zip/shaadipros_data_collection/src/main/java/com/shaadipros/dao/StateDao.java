package com.shaadipros.dao;

import org.springframework.data.repository.CrudRepository;

import com.shaadipros.entity.State;

public interface StateDao extends CrudRepository<State, Integer>  {

}
